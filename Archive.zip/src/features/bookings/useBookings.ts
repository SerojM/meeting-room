import { useQuery } from '@tanstack/react-query'
import { getBookings } from './api.ts'

export function bookingsQueryKey(date: string) {
  return ['bookings', date] as const
}

export function useBookings(date: string) {
  return useQuery({
    queryKey: bookingsQueryKey(date),
    queryFn: ({ signal }) => getBookings(date, signal),
  })
}
